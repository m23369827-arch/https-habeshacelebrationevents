import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'am';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.services': 'Services',
    'nav.about': 'About',
    'nav.gallery': 'Gallery',
    'nav.contact': 'Contact',
    'nav.book': 'Book Now',

    // Hero Section
    'hero.headline': 'Luxury Ethiopian Events, Designed to Be Remembered',
    'hero.subheadline': 'We craft unforgettable celebrations through culture, cuisine, and elegance.',
    'hero.cta': 'Reserve Your Event',

    // Food Section
    'food.title': 'Authentic Ethiopian Cuisine',
    'food.description': 'Experience the rich flavors of Ethiopia through our traditional dishes, crafted to bring culture and celebration to every event.',
    'food.injera': 'Injera with Doro Wat',
    'food.kitfo': 'Kitfo',
    'food.tibs': 'Tibs',
    'food.shiro': 'Shiro',
    'food.beyaynetu': 'Beyaynetu',
    'food.coffee': 'Ethiopian Coffee Ceremony',

    // Events Section
    'events.title': 'Curated Celebrations',
    'events.description': 'We design unforgettable experiences from weddings to private celebrations.',
    'events.weddings': 'Weddings',
    'events.ceremonies': 'Cultural Ceremonies',
    'events.private': 'Private Events',
    'events.corporate': 'Corporate Events',

    // Video Section
    'video.title': 'Experience the Celebration',
    'video.description': 'Watch real moments from our most memorable events',

    // Testimonials
    'testimonials.title': 'What Our Clients Say',
    'testimonials.client1': 'Habesha Celebration Events made our wedding day absolutely magical. Every detail was perfect, and they honored our traditions beautifully.',
    'testimonials.client1.name': 'Almaz & Dawit',
    'testimonials.client2': 'From the food to the music to the decorations, everything was exceptional. They truly understand Ethiopian culture.',
    'testimonials.client2.name': 'Hiwot & Yohannes',
    'testimonials.client3': 'Professional, authentic, and absolutely stunning. We felt like royalty at our celebration.',
    'testimonials.client3.name': 'Tigist & Abebe',

    // CTA Section
    'cta.title': "Let's Create Something Unforgettable",
    'cta.description': 'Your celebration deserves to be extraordinary. Let us bring your vision to life with authenticity and elegance.',
    'cta.button': 'Book Your Event',

    // Contact Section
    'contact.title': 'Get in Touch',
    'contact.description': 'Ready to plan your celebration? Contact us today.',
    'contact.name': 'Name',
    'contact.email': 'Email',
    'contact.phone': 'Phone',
    'contact.message': 'Message',
    'contact.submit': 'Send Message',
    'contact.phone_label': 'Phone',
    'contact.whatsapp_label': 'WhatsApp',
    'contact.location': 'Location',

    // Footer
    'footer.tagline': 'Where Ethiopian Tradition Meets Modern Luxury',
    'footer.followus': 'Follow Us',
    'footer.copyright': '© 2026 Habesha Celebration Events. All rights reserved.',
  },
  am: {
    // Navigation
    'nav.home': 'ዋና ገጽ',
    'nav.services': 'አገልግሎቶች',
    'nav.about': 'ስለ ኛ',
    'nav.gallery': '갤러리',
    'nav.contact': 'ያግኙን',
    'nav.book': 'አሁን ይያዙ',

    // Hero Section
    'hero.headline': 'የተከበሩ የኢትዮጵያ ዝግጅቶች፣ ለመታሰቢያ የተነደፉ',
    'hero.subheadline': 'በባህል፣ በምግብ እና በውበት የማይረሱ ዝግጅቶችን እንፈጥራለን።',
    'hero.cta': 'ዝግጅትዎን ያስይዙ',

    // Food Section
    'food.title': 'እውነተኛ የኢትዮጵያ ምግብ',
    'food.description': 'የኢትዮጵያን የተለያዩ ጣዕሞች በባህላዊ ምግቦቻችን ይሞክሩ፣ ዝግጅቶቻችሁን ለማስደሰት ተዘጋጅተዋል።',
    'food.injera': 'ኢንጀራ ከ ዶሮ ወት',
    'food.kitfo': 'ክትፎ',
    'food.tibs': 'ጥብስ',
    'food.shiro': 'ሺሮ',
    'food.beyaynetu': 'በያይነቱ',
    'food.coffee': 'የኢትዮጵያ ቡና ሥርዓተ ሥርዓት',

    // Events Section
    'events.title': 'የተመረጡ ዝግጅቶች',
    'events.description': 'ከሰርግ እስከ የግል ዝግጅቶች ድረስ የማይረሱ ተሞክሮዎችን እንፈጥራለን።',
    'events.weddings': 'ሰርግ',
    'events.ceremonies': 'ባህላዊ ሥርዓቶች',
    'events.private': 'የግል ዝግጅቶች',
    'events.corporate': 'የኮርፖሬት ዝግጅቶች',

    // Video Section
    'video.title': 'ዝግጅቱን ተሞክሮ ይሁኑ',
    'video.description': 'ከእኛ በጣም ታላቅ ዝግጅቶች ውስጥ ትክክለኛ ጊዜ ይመልከቱ',

    // Testimonials
    'testimonials.title': 'ደንበኞቻችን የሚሉት',
    'testimonials.client1': 'Habesha Celebration Events ሰርግ ቀናችንን ፍጹም አስደናቂ አድርጓል። እያንዳንዱ ዝርዝር ፍጹም ነበር፣ እና ባህላችንን በ아름답게ከበሩ።',
    'testimonials.client1.name': 'አልማዝ እና ዳዊት',
    'testimonials.client2': 'ከምግብ ወደ ሙዚቃ ወደ ጌጥ፣ ሁሉም ታላቅ ነበር። ሕዝብ የኢትዮጵያ ባህል በትክክል ይገነዘባሉ።',
    'testimonials.client2.name': 'ሂወት እና ዮሃንስ',
    'testimonials.client3': 'ሙያዊ፣ እውነተኛ እና ፍጹም ድንቅ። በሰርግ ቀናችን ንጉስ ወይም ንግሥት ሆነን ተሰምተናል።',
    'testimonials.client3.name': 'ትግስት እና አበበ',

    // CTA Section
    'cta.title': 'የማይረሳ ነገር እንፍጠር',
    'cta.description': 'ዝግጅትዎ ልዩ ሊሆን 합니다። ሕልምዎን ወደ ሕይወት ለማምጣት ፍቅር እና ውበት ያሳድሩ።',
    'cta.button': 'ዝግጅት ይያዙ',

    // Contact Section
    'contact.title': 'ያግኙን',
    'contact.description': 'ዝግጅትዎን ለመቅጠር ዝግጅት ነዎ? ዛሬ ያግኙን።',
    'contact.name': 'ስም',
    'contact.email': 'ኢሜይል',
    'contact.phone': 'ስልክ',
    'contact.message': 'መልእክት',
    'contact.submit': 'መልእክት ላክ',
    'contact.phone_label': 'ስልክ',
    'contact.whatsapp_label': 'ዋትስአፕ',
    'contact.location': 'ቦታ',

    // Footer
    'footer.tagline': 'የኢትዮጵያ ባህል ከዘመናዊ ሌጦ ጋር ይገናኛል',
    'footer.followus': 'ይከተሉን',
    'footer.copyright': '© 2026 Habesha Celebration Events. ሁሉም መብቶች የተጠበቁ ናቸው።',
  }
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>('en');

  useEffect(() => {
    const saved = localStorage.getItem('language') as Language | null;
    if (saved) {
      setLanguageState(saved);
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('language', lang);
  };

  const t = (key: string): string => {
    return (translations[language] as Record<string, string>)[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
