/* ============================================================
   HOME PAGE — Habesha Celebration Events
   Design: Ethiopian Royal Court Maximalism
   Assembles all sections in order
   ============================================================ */
import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import AboutSection from "../components/AboutSection";
import ServicesSection from "../components/ServicesSection";
import CateringSection from "../components/CateringSection";
import WhyChooseSection from "../components/WhyChooseSection";
import ProcessSection from "../components/ProcessSection";
import GallerySection from "../components/GallerySection";
import TestimonialsSection from "../components/TestimonialsSection";
import ContactSection from "../components/ContactSection";
import Footer from "../components/Footer";
import FloatingWhatsApp from "../components/FloatingWhatsApp";

export default function Home() {
  return (
    <div className="min-h-screen bg-midnight text-ivory">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <CateringSection />
      <WhyChooseSection />
      <ProcessSection />
      <GallerySection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
