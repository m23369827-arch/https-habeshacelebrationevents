import { useLanguage } from '@/contexts/LanguageContext';
import { Globe } from 'lucide-react';

export default function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-2 bg-gold/10 rounded-full p-1">
      <button
        onClick={() => setLanguage('en')}
        className={`px-3 py-1 rounded-full text-sm font-medium transition-all ${
          language === 'en'
            ? 'bg-gold text-midnight'
            : 'text-gold hover:bg-gold/20'
        }`}
      >
        English
      </button>
      <button
        onClick={() => setLanguage('am')}
        className={`px-3 py-1 rounded-full text-sm font-medium transition-all ${
          language === 'am'
            ? 'bg-gold text-midnight'
            : 'text-gold hover:bg-gold/20'
        }`}
      >
        አማርኛ
      </button>
    </div>
  );
}
