/* ============================================================
   FLOATING WHATSAPP BUTTON — Quick contact access
   ============================================================ */
import { MessageCircle } from "lucide-react";
import { useState } from "react";

export default function FloatingWhatsApp() {
  const [hovered, setHovered] = useState(false);

  return (
    <a
      href="https://wa.me/27712345678?text=Hello%20Habesha%20Celebration%20Events!%20I%20would%20like%20to%20enquire%20about%20your%20services."
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 group"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      aria-label="Contact us on WhatsApp"
    >
      {/* Tooltip */}
      <div
        className={`transition-all duration-300 ${hovered ? "opacity-100 translate-x-0" : "opacity-0 translate-x-4"}`}
      >
        <div className="bg-midnight border border-gold/40 px-3 py-2 whitespace-nowrap shadow-lg">
          <p style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-xs tracking-wider">Chat with us</p>
        </div>
      </div>

      {/* Button */}
      <div className="w-14 h-14 bg-green-600 hover:bg-green-500 flex items-center justify-center shadow-2xl transition-all duration-300 hover:scale-110 relative">
        <MessageCircle size={26} className="text-white" />
        {/* Pulse ring */}
        <div className="absolute inset-0 bg-green-500 animate-ping opacity-30 rounded-none" />
      </div>
    </a>
  );
}
