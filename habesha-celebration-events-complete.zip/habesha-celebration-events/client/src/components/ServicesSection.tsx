/* ============================================================
   SERVICES SECTION — Ethiopian Royal Court Maximalism
   Grid of service cards with icons, gold accents
   ============================================================ */
import { useReveal } from "../hooks/useReveal";
import { useLanguage } from "@/contexts/LanguageContext";
import { 
  Heart, Camera, Utensils, Shirt, Sparkles, 
  Mail, Users, Flower2, Star, Music
} from "lucide-react";

const services = [
  {
    icon: Heart,
    title: "Wedding Planning",
    subtitle: "Full-Service Coordination",
    desc: "Complete wedding planning from church coordination, pre-wedding welcome ceremony, guest coordination, music, and on-the-day management. Your dream wedding, perfectly orchestrated.",
    features: ["Church & civil ceremony coordination", "Pre-wedding welcome ceremony", "Guest management & seating", "Music & entertainment"],
  },
  {
    icon: Camera,
    title: "Photography & Videography",
    subtitle: "Cinematic Memories",
    desc: "Professional photography and videography capturing every precious moment — from the engagement shoot to the final dance. Drone footage, cinematic highlight reels, and premium albums.",
    features: ["Pre-wedding & engagement shoots", "Ceremony & reception coverage", "Cinematic highlight videos", "Drone photography & aerial shots"],
  },
  {
    icon: Utensils,
    title: "Catering Services",
    subtitle: "Authentic Ethiopian Cuisine",
    desc: "A magnificent spread of traditional Ethiopian ceremonial dishes served with warmth and elegance. Full buffet setup, professional serving staff, and complete guest dining management.",
    features: ["Doro Wat, Tibs, Kitfo, Gomen", "Traditional coffee ceremony", "Tej honey wine & Ethiopian drinks", "Full buffet & serving management"],
  },
  {
    icon: Shirt,
    title: "Dress Rental & Purchase",
    subtitle: "Traditional & Modern Attire",
    desc: "An exquisite collection of Habesha Kemis, traditional groom outfits, modern bridal gowns, and complete bridal party attire. Look stunning on your most important day.",
    features: ["Habesha Kemis for brides", "Traditional groom outfits", "Modern bridal gowns & suits", "Bridesmaids & groomsmen attire"],
  },
  {
    icon: Sparkles,
    title: "Makeup & Beauty",
    subtitle: "Bridal Glamour",
    desc: "Professional bridal makeup, groom grooming, family makeup services, and on-the-day touch-ups. Our beauty team ensures everyone looks their absolute best.",
    features: ["Bridal makeup & hair styling", "Groom grooming services", "Family & bridal party makeup", "On-the-day touch-up team"],
  },
  {
    icon: Mail,
    title: "Invitation Design",
    subtitle: "Digital & Printed",
    desc: "Beautifully designed Ethiopian-themed invitation cards — both digital and printed. RSVP management and guest communication handled professionally.",
    features: ["Ethiopian-themed custom designs", "Digital & printed invitations", "RSVP management system", "Guest communication support"],
  },
  {
    icon: Users,
    title: "Wedding Support Team",
    subtitle: "Traditional Ceremony Roles",
    desc: "A dedicated traditional wedding support team including best man, maid of honor, bridesmaids, groomsmen, and on-site event support staff for a seamless ceremony.",
    features: ["Best man & maid of honor", "Bridesmaids & groomsmen", "On-site event coordinators", "Traditional ceremony support"],
  },
  {
    icon: Flower2,
    title: "Decoration & Venue Setup",
    subtitle: "Luxury Décor",
    desc: "Breathtaking venue transformation with stage design, floral arrangements, table settings, lighting design, and authentic Ethiopian cultural décor elements.",
    features: ["Stage & backdrop design", "Floral arrangements", "Lighting & ambiance setup", "Cultural décor elements"],
  },
  {
    icon: Star,
    title: "Other Events",
    subtitle: "Beyond Weddings",
    desc: "Birthday celebrations, anniversaries, graduation parties, and cultural community events — all planned with the same dedication and elegance as our weddings.",
    features: ["Birthday celebrations", "Anniversary events", "Graduation parties", "Cultural & community events"],
  },
  {
    icon: Music,
    title: "Entertainment & Music",
    subtitle: "Live & DJ Services",
    desc: "Traditional Ethiopian music, live bands, modern DJ services, and cultural performances including Eskista dance. Create an atmosphere that moves every guest.",
    features: ["Traditional Ethiopian music", "Live band & DJ services", "Eskista cultural performances", "Sound & lighting systems"],
  },
];

export default function ServicesSection() {
  const { ref: titleRef, visible: titleVisible } = useReveal();

  return (
    <section id="services" className="py-24 relative" style={{ background: "linear-gradient(180deg, #0D0A05 0%, #120E08 50%, #0D0A05 100%)" }}>
      {/* Tibeb top border */}
      <div className="tibeb-border absolute top-0 left-0 right-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> What We Offer <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Our Complete Services
          </h2>
          <div className="gold-divider" />
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-lg max-w-2xl mx-auto mt-4">
            Everything you need for your perfect Ethiopian celebration — under one roof, delivered by one dedicated team.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service, i) => (
            <ServiceCard key={service.title} service={service} delay={i * 60} />
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/60 text-lg italic mb-6">
            Ready to start planning your dream celebration?
          </p>
          <button
            onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
            className="btn-gold"
          >
            Get a Free Consultation
          </button>
        </div>
      </div>

      {/* Tibeb bottom border */}
      <div className="tibeb-border absolute bottom-0 left-0 right-0" />
    </section>
  );
}

function ServiceCard({ service, delay }: { service: typeof services[0]; delay: number }) {
  const { ref, visible } = useReveal();
  const Icon = service.icon;

  return (
    <div
      ref={ref}
      className={`reveal ${visible ? "visible" : ""} service-card p-6`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 border border-gold/40 flex items-center justify-center flex-shrink-0">
          <Icon size={18} className="text-gold" />
        </div>
        <div>
          <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-sm font-semibold tracking-wide leading-tight">{service.title}</h3>
          <p style={{ fontFamily: "'Lato', sans-serif" }} className="text-gold text-xs tracking-wider opacity-80">{service.subtitle}</p>
        </div>
      </div>
      <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/60 text-sm leading-relaxed mb-4">{service.desc}</p>
      <ul className="space-y-1">
        {service.features.map((f) => (
          <li key={f} className="flex items-start gap-2">
            <span className="text-gold text-xs mt-0.5 flex-shrink-0">✦</span>
            <span style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/50 text-xs">{f}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
