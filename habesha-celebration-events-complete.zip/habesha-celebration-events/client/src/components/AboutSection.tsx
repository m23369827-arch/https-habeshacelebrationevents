/* ============================================================
   ABOUT SECTION — Ethiopian Royal Court Maximalism
   Asymmetric layout: image left, text right
   ============================================================ */
import { useReveal } from "../hooks/useReveal";

const TEAM_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/about-team-5Qd55yT9YCjmpEkFyzieg2.webp";

const values = [
  { icon: "✦", title: "Cultural Authenticity", desc: "We honour Ethiopian traditions with deep respect and pride, weaving them into every celebration." },
  { icon: "✦", title: "All-in-One Excellence", desc: "From planning to photography, catering to décor — one professional team handles everything." },
  { icon: "✦", title: "Luxury & Elegance", desc: "We deliver premium, world-class experiences that reflect the grandeur your special day deserves." },
  { icon: "✦", title: "Community & Family", desc: "We serve the Ethiopian community in South Africa with warmth, care, and personal dedication." },
];

export default function AboutSection() {
  const { ref: ref1, visible: v1 } = useReveal();
  const { ref: ref2, visible: v2 } = useReveal();

  return (
    <section id="about" className="py-24 bg-midnight relative overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-3"
        style={{
          backgroundImage: `repeating-linear-gradient(45deg, rgba(212,168,67,0.03) 0px, rgba(212,168,67,0.03) 1px, transparent 1px, transparent 20px)`,
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <div
            ref={ref1}
            className={`reveal ${v1 ? "visible" : ""} relative`}
          >
            <div className="relative">
              {/* Gold frame */}
              <div className="absolute -top-4 -left-4 w-full h-full border border-gold/30" />
              <img
                src={TEAM_IMAGE}
                alt="Habesha Celebration Events Team"
                className="w-full object-cover"
                style={{ aspectRatio: "4/3" }}
              />
              {/* Gold corner accents */}
              <div className="absolute top-0 left-0 w-12 h-12 border-t-2 border-l-2 border-gold" />
              <div className="absolute bottom-0 right-0 w-12 h-12 border-b-2 border-r-2 border-gold" />
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-6 bg-midnight border border-gold/40 p-6 text-center shadow-2xl hidden sm:block">
              <div style={{ fontFamily: "'Cinzel Decorative', serif" }} className="text-gold text-2xl font-bold">10+</div>
              <div style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/60 text-xs tracking-widest uppercase mt-1">Years of Excellence</div>
            </div>
          </div>

          {/* Text */}
          <div
            ref={ref2}
            className={`reveal ${v2 ? "visible" : ""}`}
          >
            <p className="section-label mb-3">
              <span className="eth-cross">✦</span> Our Story
            </p>
            <h2
              style={{ fontFamily: "'Cinzel', serif" }}
              className="text-ivory text-3xl sm:text-4xl font-bold mb-2 leading-tight"
            >
              Celebrating Ethiopian
            </h2>
            <h2
              style={{ fontFamily: "'Cinzel', serif" }}
              className="text-gold text-3xl sm:text-4xl font-bold mb-6 leading-tight"
            >
              Heritage with Pride
            </h2>
            <div className="gold-divider-left" />

            <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/75 text-lg leading-relaxed mb-5">
              Habesha Celebration Events was founded with a singular vision: to give the Ethiopian community in South Africa access to world-class, culturally authentic event planning — without the need to coordinate dozens of different vendors.
            </p>
            <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/75 text-lg leading-relaxed mb-8">
              We are a full-service team of passionate professionals who understand the depth and beauty of Ethiopian wedding traditions. From the sacred coffee ceremony to the joyful Eskista dance, we honour every moment with the care it deserves.
            </p>

            {/* Mission & Vision */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              <div className="border border-gold/20 p-5">
                <h4 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-sm tracking-widest uppercase mb-2">Our Mission</h4>
                <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-base">To deliver unforgettable celebrations that honour Ethiopian culture while exceeding modern luxury expectations.</p>
              </div>
              <div className="border border-gold/20 p-5">
                <h4 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-sm tracking-widest uppercase mb-2">Our Vision</h4>
                <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-base">To be the most trusted and celebrated Ethiopian event planning company in Southern Africa.</p>
              </div>
            </div>

            {/* Values */}
            <div className="grid sm:grid-cols-2 gap-3">
              {values.map((v) => (
                <div key={v.title} className="flex gap-3 items-start">
                  <span className="text-gold mt-1 text-sm">{v.icon}</span>
                  <div>
                    <h5 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-xs tracking-wider uppercase mb-1">{v.title}</h5>
                    <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/55 text-sm leading-relaxed">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
