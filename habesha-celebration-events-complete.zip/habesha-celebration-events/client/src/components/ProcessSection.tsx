/* ============================================================
   PROCESS SECTION — Ethiopian Royal Court Maximalism
   Step-by-step planning process with numbered steps
   ============================================================ */
import { useReveal } from "../hooks/useReveal";

const steps = [
  {
    number: "01",
    title: "Free Consultation",
    desc: "We begin with a complimentary consultation to understand your vision, cultural preferences, budget, and event requirements.",
  },
  {
    number: "02",
    title: "Custom Proposal",
    desc: "Our team crafts a detailed, personalised proposal covering all services, timeline, and investment — tailored specifically to your celebration.",
  },
  {
    number: "03",
    title: "Planning & Coordination",
    desc: "We handle every detail: venue, catering, décor, photography, attire, and more. You receive regular updates and have full visibility throughout.",
  },
  {
    number: "04",
    title: "Your Perfect Day",
    desc: "On the day, our dedicated team is present from setup to teardown, ensuring every moment unfolds beautifully and stress-free.",
  },
];

export default function ProcessSection() {
  const { ref: titleRef, visible: titleVisible } = useReveal();

  return (
    <section className="py-24 bg-midnight relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> How It Works <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Your Journey to a Perfect Celebration
          </h2>
          <div className="gold-divider" />
        </div>

        {/* Steps */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, i) => (
            <StepCard key={step.number} step={step} delay={i * 100} isLast={i === steps.length - 1} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StepCard({ step, delay, isLast }: { step: typeof steps[0]; delay: number; isLast: boolean }) {
  const { ref, visible } = useReveal();

  return (
    <div
      ref={ref}
      className={`reveal ${visible ? "visible" : ""} relative`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {/* Connector line */}
      {!isLast && (
        <div className="hidden lg:block absolute top-8 left-full w-full h-px bg-gradient-to-r from-gold/40 to-transparent z-0" style={{ width: "calc(100% - 4rem)", left: "calc(4rem)" }} />
      )}

      <div className="relative z-10">
        {/* Number */}
        <div
          style={{ fontFamily: "'Cinzel Decorative', serif" }}
          className="text-gold/20 text-6xl font-bold leading-none mb-4 select-none"
        >
          {step.number}
        </div>

        {/* Gold dot */}
        <div className="w-3 h-3 bg-gold mb-5" />

        <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-base font-semibold tracking-wide mb-3">
          {step.title}
        </h3>
        <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/60 text-base leading-relaxed">
          {step.desc}
        </p>
      </div>
    </div>
  );
}
