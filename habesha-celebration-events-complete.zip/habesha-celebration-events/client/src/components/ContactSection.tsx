/* ============================================================
   CONTACT SECTION — Ethiopian Royal Court Maximalism
   Contact form + info panel with WhatsApp, phone, email
   ============================================================ */
import { useState } from "react";
import { useReveal } from "../hooks/useReveal";
import { useLanguage } from "@/contexts/LanguageContext";
import { Phone, Mail, MapPin, MessageCircle, Instagram, Facebook, Send, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function ContactSection() {
  const { t } = useLanguage();
  const { ref: titleRef, visible: titleVisible } = useReveal();
  const { ref: formRef, visible: formVisible } = useReveal();
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    eventType: "",
    eventDate: "",
    guestCount: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error("Please fill in all required fields.");
      return;
    }
    setLoading(true);
    // Simulate submission
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      toast.success("Your consultation request has been sent! We will contact you within 24 hours.");
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 relative" style={{ background: "linear-gradient(180deg, #0A0805 0%, #0D0A05 100%)" }}>
      <div className="tibeb-border absolute top-0 left-0 right-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> {t("contact.title")} <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Begin Your Journey
          </h2>
          <div className="gold-divider" />
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-lg max-w-2xl mx-auto mt-4">
            {t("contact.description")}
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-lg font-semibold mb-6 tracking-wide">
                Contact Information
              </h3>
              <div className="space-y-5">
                <ContactItem
                  icon={Phone}
                  label="Phone"
                  value="+27 (0) 12 345 6789"
                  href="tel:+27123456789"
                />
                <ContactItem
                  icon={MessageCircle}
                  label="WhatsApp"
                  value="+27 (0) 71 234 5678"
                  href="https://wa.me/27712345678"
                />
                <ContactItem
                  icon={Mail}
                  label="Email"
                  value="info@habeshaevents.co.za"
                  href="mailto:info@habeshaevents.co.za"
                />
                <ContactItem
                  icon={MapPin}
                  label="Location"
                  value="Johannesburg, South Africa"
                  href="https://maps.google.com/?q=Johannesburg,South+Africa"
                />
              </div>
            </div>

            {/* Social media */}
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-sm tracking-widest uppercase mb-4">
                Follow Us
              </h3>
              <div className="flex gap-3">
                <SocialButton icon={Instagram} label="Instagram" href="https://instagram.com" />
                <SocialButton icon={Facebook} label="Facebook" href="https://facebook.com" />
                <SocialButton icon={MessageCircle} label="WhatsApp" href="https://wa.me/27712345678" />
              </div>
            </div>

            {/* Office hours */}
            <div className="border border-gold/20 p-6">
              <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-sm tracking-widest uppercase mb-4">
                Office Hours
              </h3>
              <div className="space-y-2">
                {[
                  { days: "Monday – Friday", hours: "8:00 AM – 6:00 PM" },
                  { days: "Saturday", hours: "9:00 AM – 4:00 PM" },
                  { days: "Sunday", hours: "By Appointment" },
                ].map((row) => (
                  <div key={row.days} className="flex justify-between">
                    <span style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/60 text-sm">{row.days}</span>
                    <span style={{ fontFamily: "'Lato', sans-serif" }} className="text-gold/80 text-sm">{row.hours}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Service areas */}
            <div>
              <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-sm tracking-widest uppercase mb-3">
                Service Areas
              </h3>
              <div className="flex flex-wrap gap-2">
                {["Johannesburg", "Pretoria", "Cape Town", "Durban", "All of South Africa"].map((city) => (
                  <span key={city} className="border border-gold/25 px-3 py-1 text-ivory/60 text-xs" style={{ fontFamily: "'Lato', sans-serif" }}>
                    {city}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Contact form */}
          <div
            ref={formRef}
            className={`reveal ${formVisible ? "visible" : ""} lg:col-span-3`}
          >
            {submitted ? (
              <div className="border border-gold/30 p-12 text-center h-full flex flex-col items-center justify-center">
                <CheckCircle size={56} className="text-gold mb-6" />
                <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-2xl font-bold mb-3">
                  Thank You!
                </h3>
                <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/70 text-lg">
                  Your consultation request has been received. Our team will contact you within 24 hours to begin planning your perfect celebration.
                </p>
                <div className="gold-divider mt-6" />
                <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-gold italic text-base mt-4">
                  "Every great celebration begins with a single conversation."
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-5">
                  <FormField label="Full Name *" name="name" type="text" placeholder="Your full name" value={form.name} onChange={handleChange} />
                  <FormField label="Email Address *" name="email" type="email" placeholder="your@email.com" value={form.email} onChange={handleChange} />
                </div>
                <div className="grid sm:grid-cols-2 gap-5">
                  <FormField label="Phone Number" name="phone" type="tel" placeholder="+27 (0) XX XXX XXXX" value={form.phone} onChange={handleChange} />
                  <div>
                    <label className="form-label">Event Type</label>
                    <select
                      name="eventType"
                      value={form.eventType}
                      onChange={handleChange}
                      className="form-input"
                    >
                      <option value="">Select event type</option>
                      <option value="wedding">Traditional Ethiopian Wedding</option>
                      <option value="reception">Wedding Reception</option>
                      <option value="engagement">Engagement Ceremony</option>
                      <option value="birthday">Birthday Celebration</option>
                      <option value="anniversary">Anniversary</option>
                      <option value="graduation">Graduation Party</option>
                      <option value="cultural">Cultural / Community Event</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-5">
                  <FormField label="Event Date" name="eventDate" type="date" placeholder="" value={form.eventDate} onChange={handleChange} />
                  <div>
                    <label className="form-label">Expected Guests</label>
                    <select
                      name="guestCount"
                      value={form.guestCount}
                      onChange={handleChange}
                      className="form-input"
                    >
                      <option value="">Select guest count</option>
                      <option value="50">Under 50</option>
                      <option value="100">50 – 100</option>
                      <option value="200">100 – 200</option>
                      <option value="300">200 – 300</option>
                      <option value="500">300 – 500</option>
                      <option value="500+">500+</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="form-label">Message *</label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Tell us about your vision, special requirements, or any questions you have..."
                    rows={5}
                    className="form-input resize-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-gold w-full flex items-center justify-center gap-3"
                >
                  {loading ? (
                    <span>Sending...</span>
                  ) : (
                    <>
                      <Send size={16} />
                      Send Consultation Request
                    </>
                  )}
                </button>
                <p style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/35 text-xs text-center">
                  We respond within 24 hours. Your information is kept strictly confidential.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function FormField({
  label, name, type, placeholder, value, onChange
}: {
  label: string; name: string; type: string; placeholder: string;
  value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  return (
    <div>
      <label className="form-label">{label}</label>
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="form-input"
      />
    </div>
  );
}

function ContactItem({ icon: Icon, label, value, href }: { icon: any; label: string; value: string; href: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="flex items-start gap-4 group">
      <div className="w-10 h-10 border border-gold/30 flex items-center justify-center flex-shrink-0 group-hover:bg-gold group-hover:border-gold transition-all duration-300">
        <Icon size={16} className="text-gold group-hover:text-midnight transition-colors duration-300" />
      </div>
      <div>
        <p style={{ fontFamily: "'Lato', sans-serif" }} className="text-gold/70 text-xs tracking-widest uppercase mb-0.5">{label}</p>
        <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/80 text-base group-hover:text-gold transition-colors duration-300">{value}</p>
      </div>
    </a>
  );
}

function SocialButton({ icon: Icon, label, href }: { icon: any; label: string; href: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="w-10 h-10 border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-midnight transition-all duration-300"
    >
      <Icon size={16} />
    </a>
  );
}
