/* ============================================================
   TESTIMONIALS SECTION — Ethiopian Royal Court Maximalism
   Carousel of client testimonials with gold star ratings
   ============================================================ */
import { useState } from "react";
import { useReveal } from "../hooks/useReveal";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Tigist & Dawit Bekele",
    event: "Traditional Ethiopian Wedding, Johannesburg",
    stars: 5,
    text: "Habesha Celebration Events turned our dream wedding into reality. From the breathtaking Habesha Kemis they sourced for me, to the most authentic Doro Wat I have ever tasted at a wedding — every detail was perfect. Our guests are still talking about it months later. We cannot thank this team enough.",
    initials: "TB",
  },
  {
    name: "Meron & Solomon Haile",
    event: "Wedding & Coffee Ceremony, Cape Town",
    stars: 5,
    text: "The coffee ceremony they organised was the most moving part of our entire wedding day. The team understood our traditions deeply and executed everything with such grace and professionalism. The decoration was absolutely stunning — like something from a royal palace. Highly recommend to every Ethiopian family.",
    initials: "MH",
  },
  {
    name: "Hiwot Tesfaye",
    event: "Birthday Celebration, Pretoria",
    stars: 5,
    text: "I hired Habesha Celebration Events for my 40th birthday and they exceeded every expectation. The venue setup was magnificent, the catering was incredible, and the team was so warm and attentive throughout the entire event. I felt like royalty. This is the only event company I will ever use.",
    initials: "HT",
  },
  {
    name: "Yonas & Selam Girma",
    event: "Wedding Reception, Durban",
    stars: 5,
    text: "As Ethiopians living in South Africa, we were worried about finding a team that truly understood our culture. Habesha Celebration Events not only understood — they celebrated it with us. The photography was cinematic, the food was divine, and the decoration was beyond our imagination. A truly five-star experience.",
    initials: "YG",
  },
  {
    name: "Almaz Worku",
    event: "Anniversary Celebration, Johannesburg",
    stars: 5,
    text: "For our 25th wedding anniversary, we wanted something special and culturally meaningful. The team created a beautiful evening that honoured our Ethiopian heritage while feeling completely modern and luxurious. The Tej honey wine service was a wonderful touch. Absolutely outstanding.",
    initials: "AW",
  },
];

export default function TestimonialsSection() {
  const { ref: titleRef, visible: titleVisible } = useReveal();
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent((c) => (c === 0 ? testimonials.length - 1 : c - 1));
  const next = () => setCurrent((c) => (c === testimonials.length - 1 ? 0 : c + 1));

  const t = testimonials[current];

  return (
    <section id="testimonials" className="py-24 bg-midnight relative overflow-hidden">
      {/* Background pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, rgba(212,168,67,0.3) 0%, transparent 60%)`,
        }}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> Client Stories <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Words from Our Families
          </h2>
          <div className="gold-divider" />
        </div>

        {/* Main testimonial */}
        <div className="testimonial-card p-8 sm:p-12 relative mb-8">
          <Quote className="text-gold/20 absolute top-6 left-6" size={48} />
          
          {/* Stars */}
          <div className="flex gap-1 mb-6 justify-center">
            {Array.from({ length: t.stars }).map((_, i) => (
              <span key={i} className="text-gold text-lg">★</span>
            ))}
          </div>

          {/* Quote */}
          <blockquote
            style={{ fontFamily: "'Crimson Text', serif" }}
            className="text-ivory/85 text-xl sm:text-2xl italic leading-relaxed text-center mb-8"
          >
            "{t.text}"
          </blockquote>

          {/* Author */}
          <div className="flex items-center justify-center gap-4">
            <div className="w-12 h-12 border border-gold/40 flex items-center justify-center bg-gold/10">
              <span style={{ fontFamily: "'Cinzel', serif" }} className="text-gold font-bold text-sm">{t.initials}</span>
            </div>
            <div>
              <p style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-sm font-semibold tracking-wide">{t.name}</p>
              <p style={{ fontFamily: "'Lato', sans-serif" }} className="text-gold/70 text-xs tracking-wider">{t.event}</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-center gap-6">
          <button
            onClick={prev}
            className="w-10 h-10 border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-midnight transition-all duration-300"
          >
            <ChevronLeft size={18} />
          </button>

          {/* Dots */}
          <div className="flex gap-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2 h-2 transition-all duration-300 ${i === current ? "bg-gold w-6" : "bg-gold/30"}`}
              />
            ))}
          </div>

          <button
            onClick={next}
            className="w-10 h-10 border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-midnight transition-all duration-300"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        {/* Trust badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-16 pt-12 border-t border-gold/15">
          {[
            { number: "500+", label: "Events Planned" },
            { number: "1000+", label: "Happy Clients" },
            { number: "10+", label: "Years Experience" },
            { number: "100%", label: "Satisfaction Rate" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div style={{ fontFamily: "'Cinzel Decorative', serif" }} className="text-gold text-2xl sm:text-3xl font-bold">{stat.number}</div>
              <div style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/50 text-xs tracking-widest uppercase mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
