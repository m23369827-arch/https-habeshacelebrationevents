/* ============================================================
   CATERING SECTION — Ethiopian Royal Court Maximalism
   Full-width image + menu items grid
   ============================================================ */
import { useReveal } from "../hooks/useReveal";
import { useLanguage } from "@/contexts/LanguageContext";

const CATERING_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/food-ethiopian-feast-QvdBLn2u2BJTnMGmkk7nGA.webp";
const COFFEE_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/coffee-ceremony-luxury-nBHJrywDHWsFYPXCG2E9jf.webp";

const dishes = [
  { name: "Doro Wat", desc: "Ethiopia's beloved spiced chicken stew with boiled eggs, slow-cooked in rich berbere sauce" },
  { name: "Tibs", desc: "Sautéed tender beef or lamb with vegetables, herbs, and aromatic spices" },
  { name: "Kitfo", desc: "Ethiopian-style minced beef seasoned with mitmita and niter kibbeh — a ceremonial delicacy" },
  { name: "Gomen", desc: "Braised collard greens with garlic, ginger, and Ethiopian spices" },
  { name: "Misir Wat", desc: "Hearty red lentil stew cooked with berbere and onions" },
  { name: "Shiro Wat", desc: "Smooth chickpea flour stew, a beloved vegetarian staple" },
  { name: "Ayib", desc: "Fresh Ethiopian cottage cheese, a cooling accompaniment to spiced dishes" },
  { name: "Firfir", desc: "Torn injera sautéed with berbere sauce and spiced butter" },
  { name: "Injera Platters", desc: "Traditional sourdough flatbread — the foundation of every Ethiopian feast" },
  { name: "Coffee Ceremony", desc: "The sacred three-round Ethiopian coffee ceremony with frankincense and popcorn" },
  { name: "Tej Honey Wine", desc: "Traditional Ethiopian honey mead, served in ceremonial berele glasses" },
  { name: "Ethiopian Drinks", desc: "Tella, Borde, fresh juices, and traditional non-alcoholic beverages" },
];

export default function CateringSection() {
  const { t } = useLanguage();
  const { ref: titleRef, visible: titleVisible } = useReveal();
  const { ref: imgRef, visible: imgVisible } = useReveal();
  const { ref: coffeeRef, visible: coffeeVisible } = useReveal();

  return (
    <section id="catering" className="py-24 bg-midnight relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> {t("food.title")} <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            A Feast Fit for Royalty
          </h2>
          <div className="gold-divider" />
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-lg max-w-2xl mx-auto mt-4">
            {t("food.description")}
          </p>
        </div>

        {/* Main catering image */}
        <div
          ref={imgRef}
          className={`reveal ${imgVisible ? "visible" : ""} relative mb-16`}
        >
          <div className="relative overflow-hidden" style={{ maxHeight: "480px" }}>
            <img
              src={CATERING_IMAGE}
              alt="Ethiopian wedding feast with injera platter"
              className="w-full object-cover"
              style={{ maxHeight: "480px" }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-midnight/80 via-transparent to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <p style={{ fontFamily: "'Cinzel Decorative', serif" }} className="text-gold text-xl sm:text-2xl font-bold">
                Traditional Ethiopian Wedding Feast
              </p>
              <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/80 text-base italic mt-1">
                Doro Wat · Tibs · Kitfo · Gomen · Misir Wat · Injera · and more
              </p>
            </div>
          </div>
        </div>

        {/* Menu grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-16">
          {dishes.map((dish, i) => (
            <DishCard key={dish.name} dish={dish} delay={i * 50} />
          ))}
        </div>

        {/* Coffee ceremony feature */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div
            ref={coffeeRef}
            className={`reveal ${coffeeVisible ? "visible" : ""}`}
          >
            <p className="section-label mb-3">
              <span className="eth-cross">✦</span> Sacred Tradition
            </p>
            <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-2xl sm:text-3xl font-bold mb-4">
              The Ethiopian Coffee Ceremony
            </h3>
            <div className="gold-divider-left" />
            <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/75 text-lg leading-relaxed mb-4">
              The Ethiopian coffee ceremony is one of the most sacred and beautiful traditions in our culture. Performed in three rounds — Abol, Tona, and Bereka — it symbolises friendship, respect, and community.
            </p>
            <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/75 text-lg leading-relaxed mb-6">
              Our trained ceremony hosts perform this ritual with authentic jebena coffee pots, fresh-roasted beans, frankincense incense, and traditional grass mats — creating an atmosphere of profound cultural connection.
            </p>
            <div className="flex flex-wrap gap-3">
              {["Fresh-roasted coffee beans", "Authentic jebena pots", "Frankincense ceremony", "Three sacred rounds"].map((item) => (
                <span key={item} className="border border-gold/30 px-3 py-1 text-gold/80 text-xs" style={{ fontFamily: "'Lato', sans-serif", letterSpacing: "0.1em" }}>
                  {item}
                </span>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="absolute -top-3 -left-3 w-full h-full border border-gold/20" />
            <img
              src={COFFEE_IMAGE}
              alt="Ethiopian coffee ceremony"
              className="w-full object-cover relative z-10"
              style={{ aspectRatio: "4/3" }}
            />
            <div className="absolute top-0 left-0 w-10 h-10 border-t-2 border-l-2 border-gold z-20" />
            <div className="absolute bottom-0 right-0 w-10 h-10 border-b-2 border-r-2 border-gold z-20" />
          </div>
        </div>
      </div>
    </section>
  );
}

function DishCard({ dish, delay }: { dish: { name: string; desc: string }; delay: number }) {
  const { ref, visible } = useReveal();
  return (
    <div
      ref={ref}
      className={`reveal ${visible ? "visible" : ""} border border-gold/15 p-4 hover:border-gold/40 transition-all duration-300`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <h4 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-sm font-semibold mb-2 tracking-wide">{dish.name}</h4>
      <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/55 text-sm leading-relaxed">{dish.desc}</p>
    </div>
  );
}
