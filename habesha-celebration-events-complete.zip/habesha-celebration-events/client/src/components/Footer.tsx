/* ============================================================
   FOOTER — Ethiopian Royal Court Maximalism
   Dark footer with gold accents, links, and copyright
   ============================================================ */
import { Phone, Mail, MapPin, MessageCircle, Instagram, Facebook } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const quickLinks = [
  { label: "Home", href: "#home" },
  { label: "About Us", href: "#about" },
  { label: "Our Services", href: "#services" },
  { label: "Catering", href: "#catering" },
  { label: "Gallery", href: "#gallery" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

const serviceLinks = [
  "Wedding Planning",
  "Photography & Videography",
  "Catering Services",
  "Dress Rental & Purchase",
  "Makeup & Beauty",
  "Invitation Design",
  "Decoration & Venue Setup",
  "Traditional Support Team",
];

export default function Footer() {
  const { t } = useLanguage();
  const scrollTo = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-midnight border-t border-gold/20 pt-16 pb-8">
      {/* Tibeb top */}
      <div className="tibeb-border mb-16" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="mb-4 flex items-center gap-2">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/upscalemedia-transformed_81a4220c.jpeg" alt="Habesha Logo" className="h-12 w-12 object-contain" />
              <div>
                <div style={{ fontFamily: "'Cinzel Decorative', serif" }} className="text-gold text-sm font-bold tracking-widest mb-0.5">
                  Habesha
                </div>
                <div style={{ fontFamily: "'Cinzel Decorative', serif" }} className="text-ivory/70 text-xs tracking-[0.2em]">
                  Events
                </div>
              </div>
            </div>
            <div className="gold-divider-left" />
            <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/55 text-base leading-relaxed mb-5">
              Your complete all-in-one Ethiopian wedding and event planning partner in South Africa. Where tradition meets luxury.
            </p>
            <div className="flex gap-3">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                className="w-9 h-9 border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-midnight transition-all duration-300">
                <Instagram size={14} />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"
                className="w-9 h-9 border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-midnight transition-all duration-300">
                <Facebook size={14} />
              </a>
              <a href="https://wa.me/27712345678" target="_blank" rel="noopener noreferrer"
                className="w-9 h-9 border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-midnight transition-all duration-300">
                <MessageCircle size={14} />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-xs tracking-widest uppercase mb-5">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); scrollTo(link.href); }}
                    style={{ fontFamily: "'Lato', sans-serif" }}
                    className="text-ivory/50 hover:text-gold text-sm transition-colors duration-200 flex items-center gap-2"
                  >
                    <span className="text-gold/40 text-xs">✦</span>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-xs tracking-widest uppercase mb-5">Our Services</h4>
            <ul className="space-y-2">
              {serviceLinks.map((s) => (
                <li key={s}>
                  <a
                    href="#services"
                    onClick={(e) => { e.preventDefault(); scrollTo("#services"); }}
                    style={{ fontFamily: "'Lato', sans-serif" }}
                    className="text-ivory/50 hover:text-gold text-sm transition-colors duration-200 flex items-center gap-2"
                  >
                    <span className="text-gold/40 text-xs">✦</span>
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-xs tracking-widest uppercase mb-5">Contact Us</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Phone size={14} className="text-gold mt-1 flex-shrink-0" />
                <span style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/55 text-sm">+27 (0) 781500968</span>
              </div>
              <div className="flex items-start gap-3">
                <MessageCircle size={14} className="text-gold mt-1 flex-shrink-0" />
                <span style={{ fontFamily: "'Lato', sans-serif", color: '#a09a8d' }} className="text-ivory/55 text-sm">+27 (0) 752160899</span>
              </div>
              <div className="flex items-start gap-3">
                <Mail size={14} className="text-gold mt-1 flex-shrink-0" />
                <span style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/55 text-sm">info@habeshaevents.co.za</span>
              </div>
              <div className="flex items-start gap-3">
                <MapPin size={14} className="text-gold mt-1 flex-shrink-0" />
                <span style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/55 text-sm">Pretoria, South Africa</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gold/15 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p style={{ fontFamily: "'Lato', sans-serif" }} className="text-ivory/35 text-xs text-center sm:text-left">
            © {new Date().getFullYear()} Habesha Celebration Events. All rights reserved. | Ethiopian Wedding & Event Planner South Africa
          </p>
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-gold/50 text-sm italic">
            "ፍቅር ሁሉንም ያሸንፋል" — Love conquers all
          </p>
        </div>
      </div>
    </footer>
  );
}
