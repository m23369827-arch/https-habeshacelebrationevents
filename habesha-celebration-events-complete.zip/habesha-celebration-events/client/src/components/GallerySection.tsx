/* ============================================================
   GALLERY SECTION — Ethiopian Royal Court Maximalism
   Masonry-style grid with hover overlays
   ============================================================ */
import { useState } from "react";
import { useReveal } from "../hooks/useReveal";
import { useLanguage } from "@/contexts/LanguageContext";
import { X, ZoomIn } from "lucide-react";

const galleryImages = [
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/hero-ethiopian-couple-celebration-gp4MMf7A2rqmaPqk7u5kRU.webp",
    alt: "Ethiopian bride and groom in traditional Habesha attire",
    label: "Traditional Wedding Ceremony",
    colSpan: 2, rowSpan: 2,
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/luxury-event-hall-decorated-8qcDnfjUJqfUwnSubuYT6W.webp",
    alt: "Luxurious Ethiopian wedding reception hall decoration",
    label: "Grand Reception Décor",
    colSpan: 2, rowSpan: 2,
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/coffee-ceremony-luxury-nBHJrywDHWsFYPXCG2E9jf.webp",
    alt: "Ethiopian coffee ceremony with jebena",
    label: "Sacred Coffee Ceremony",
    colSpan: 1, rowSpan: 2,
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/food-ethiopian-feast-QvdBLn2u2BJTnMGmkk7nGA.webp",
    alt: "Ethiopian wedding feast injera platter",
    label: "Ceremonial Feast",
    colSpan: 1, rowSpan: 1,
  },
  {
    src: "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/celebration-eskista-dance-oSxrXScbG4JRYreoStyyEj.webp",
    alt: "Guests celebrating with traditional eskista dance",
    label: "Celebration & Dance",
    colSpan: 1, rowSpan: 1,
  },
];

// Unsplash images for additional gallery variety
const extraImages = [
  {
    src: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&q=80",
    alt: "Wedding couple portrait",
    label: "Bridal Portrait",
    colSpan: 1, rowSpan: 1,
  },
  {
    src: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=600&q=80",
    alt: "Wedding reception celebration",
    label: "Reception Celebration",
    colSpan: 1, rowSpan: 1,
  },
  {
    src: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=600&q=80",
    alt: "Wedding flowers and decoration",
    label: "Floral Arrangements",
    colSpan: 1, rowSpan: 1,
  },
];

const allImages = [...galleryImages, ...extraImages];

export default function GallerySection() {
  const { t } = useLanguage();
  const { ref: titleRef, visible: titleVisible } = useReveal();
  const [lightbox, setLightbox] = useState<null | { src: string; alt: string; label: string; colSpan: number; rowSpan: number }>(null);

  return (
    <section id="gallery" className="py-24 relative" style={{ background: "linear-gradient(180deg, #0D0A05 0%, #0A0805 100%)" }}>
      <div className="tibeb-border absolute top-0 left-0 right-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> {t("nav.gallery")} <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Moments We've Created
          </h2>
          <div className="gold-divider" />
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-lg max-w-2xl mx-auto mt-4">
            A glimpse into the celebrations we have had the honour of planning and executing for our beloved clients.
          </p>
        </div>

        {/* Gallery grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3" style={{ gridAutoRows: '200px' }}>
          {allImages.map((img, i) => (
            <GalleryItem
              key={i}
              img={img}
              delay={i * 80}
              onClick={() => setLightbox(img)}
            />
          ))}
        </div>

        <div className="text-center mt-12">
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/50 text-base italic">
            Every image tells a story of love, culture, and celebration.
          </p>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-midnight/95 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-6 right-6 text-gold hover:text-ivory transition-colors"
            onClick={() => setLightbox(null)}
          >
            <X size={32} />
          </button>
          <div className="max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            <img
              src={lightbox.src}
              alt={lightbox.alt}
              className="w-full object-contain max-h-[80vh]"
            />
            <p style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-center mt-4 tracking-widest text-sm">
              {lightbox.label}
            </p>
          </div>
        </div>
      )}
    </section>
  );
}

function GalleryItem({
  img,
  delay,
  onClick,
}: {
  img: { src: string; alt: string; label: string; colSpan: number; rowSpan: number };
  delay: number;
  onClick: () => void;
}) {
  const { ref, visible } = useReveal();

  return (
    <div
      ref={ref}
      className={`reveal ${visible ? "visible" : ""} gallery-item cursor-pointer`}
      style={{ transitionDelay: `${delay}ms`, gridColumn: `span ${img.colSpan}`, gridRow: `span ${img.rowSpan}` }}
      onClick={onClick}
    >
      <img
        src={img.src}
        alt={img.alt}
        className="w-full h-full object-cover"
      />
      <div className="overlay flex flex-col justify-end p-4">
        <div className="flex items-center gap-2">
          <ZoomIn size={14} className="text-gold" />
          <p style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-xs tracking-wider">{img.label}</p>
        </div>
      </div>
    </div>
  );
}
