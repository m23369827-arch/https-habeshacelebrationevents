/* ============================================================
   WHY CHOOSE US SECTION — Ethiopian Royal Court Maximalism
   Full-width dark section with gold feature highlights
   ============================================================ */
import { useReveal } from "../hooks/useReveal";
import { Shield, Clock, Award, Heart, Users, Star } from "lucide-react";

const DECORATION_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/gallery-decoration-FjWupZ96no2r3Z4XW2GGsU.webp";

const reasons = [
  {
    icon: Shield,
    title: "All-In-One Service",
    desc: "No need to coordinate multiple vendors. Our complete team handles every aspect of your celebration from start to finish.",
  },
  {
    icon: Heart,
    title: "Cultural Authenticity",
    desc: "We are Ethiopian, we understand Ethiopian traditions deeply, and we celebrate them with genuine pride and knowledge.",
  },
  {
    icon: Award,
    title: "Premium Quality",
    desc: "We deliver world-class, luxury-level service at every price point, ensuring your celebration exceeds all expectations.",
  },
  {
    icon: Clock,
    title: "Stress-Free Planning",
    desc: "We manage every detail so you can be fully present and enjoy your special day without worry or stress.",
  },
  {
    icon: Users,
    title: "Dedicated Team",
    desc: "A passionate, experienced team of professionals who treat your celebration as if it were their own family's event.",
  },
  {
    icon: Star,
    title: "Proven Track Record",
    desc: "Over 500 successful events and a 100% client satisfaction rate speak for the quality and dedication we bring.",
  },
];

export default function WhyChooseSection() {
  const { ref: titleRef, visible: titleVisible } = useReveal();

  return (
    <section className="py-24 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #0D0A05 0%, #120E08 100%)" }}>
      <div className="tibeb-border absolute top-0 left-0 right-0" />

      {/* Background image with overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: `url(${DECORATION_IMAGE})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-midnight/80 to-midnight/95" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          ref={titleRef}
          className={`reveal ${titleVisible ? "visible" : ""} text-center mb-16`}
        >
          <p className="section-label mb-3">
            <span className="eth-cross">✦</span> Why Habesha Events <span className="eth-cross">✦</span>
          </p>
          <h2 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            The Difference is in the Details
          </h2>
          <div className="gold-divider" />
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-lg max-w-2xl mx-auto mt-4">
            We are not just event planners — we are cultural custodians, storytellers, and celebration architects.
          </p>
        </div>

        {/* Reasons grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {reasons.map((reason, i) => (
            <ReasonCard key={reason.title} reason={reason} delay={i * 80} />
          ))}
        </div>

        {/* CTA banner */}
        <div className="border border-gold/25 p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-gold" />
          <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-gold" />
          <p style={{ fontFamily: "'Cinzel', serif" }} className="text-gold text-xs tracking-widest uppercase mb-4">
            <span className="eth-cross">✦</span> Your Dream Celebration Awaits <span className="eth-cross">✦</span>
          </p>
          <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-2xl sm:text-3xl font-bold mb-4">
            Let Us Create Something Extraordinary Together
          </h3>
          <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/65 text-lg max-w-xl mx-auto mb-8">
            From intimate family gatherings to grand wedding celebrations for 500+ guests, we bring the same dedication and excellence to every event.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
              className="btn-gold"
            >
              Book Free Consultation
            </button>
            <button
              onClick={() => document.querySelector("#gallery")?.scrollIntoView({ behavior: "smooth" })}
              className="btn-gold-outline"
            >
              View Our Gallery
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function ReasonCard({ reason, delay }: { reason: typeof reasons[0]; delay: number }) {
  const { ref, visible } = useReveal();
  const Icon = reason.icon;

  return (
    <div
      ref={ref}
      className={`reveal ${visible ? "visible" : ""} service-card p-6`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="w-12 h-12 border border-gold/40 flex items-center justify-center mb-4">
        <Icon size={20} className="text-gold" />
      </div>
      <h3 style={{ fontFamily: "'Cinzel', serif" }} className="text-ivory text-sm font-semibold tracking-wide mb-3">{reason.title}</h3>
      <p style={{ fontFamily: "'Crimson Text', serif" }} className="text-ivory/60 text-base leading-relaxed">{reason.desc}</p>
    </div>
  );
}
