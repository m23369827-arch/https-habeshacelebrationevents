/* ============================================================
   NAVBAR — Ethiopian Royal Court Maximalism
   Transparent → opaque on scroll, gold accents, Cinzel font
   ============================================================ */
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageToggle from "./LanguageToggle";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/upscalemedia-transformed_81a4220c.jpeg";

export default function Navbar() {
  const { t, language } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: t("nav.home"), href: "#home" },
    { label: t("nav.about"), href: "#about" },
    { label: t("nav.services"), href: "#services" },
    { label: t("nav.gallery"), href: "#gallery" },
    { label: t("nav.contact"), href: "#contact" },
  ];

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "navbar-scrolled" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo with Image */}
          <a
            href="#home"
            onClick={(e) => { e.preventDefault(); handleNavClick("#home"); }}
            className="flex items-center gap-2"
          >
            <img src={LOGO_URL} alt="Habesha Celebration Events" className="h-12 w-12 object-contain" />
            <span className="text-gold font-bold text-lg hidden sm:inline" style={{ fontFamily: "'Cinzel Decorative', serif" }}>
              Habesha Events
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <nav className="flex items-center gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
                  className="text-ivory/70 hover:text-gold transition text-sm font-medium"
                >
                  {link.label}
                </a>
              ))}
            </nav>
            <div className="flex items-center gap-4">
              <LanguageToggle />
              <button className="px-6 py-2 bg-gold text-midnight font-semibold rounded-lg hover:bg-gold/90 transition text-sm">
                {t("nav.book")}
              </button>
            </div>
          </div>

          {/* Mobile Menu Button & Language Toggle */}
          <div className="md:hidden flex items-center gap-4">
            <LanguageToggle />
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="text-gold hover:text-gold/80 transition"
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {menuOpen && (
          <div className="md:hidden bg-midnight/95 backdrop-blur-sm border-t border-gold/20">
            <div className="px-4 py-4 space-y-3">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
                  className="block text-ivory/70 hover:text-gold transition py-2 text-sm font-medium"
                >
                  {link.label}
                </a>
              ))}
              <button className="w-full mt-4 px-6 py-2 bg-gold text-midnight font-semibold rounded-lg hover:bg-gold/90 transition text-sm">
                {t("nav.book")}
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
