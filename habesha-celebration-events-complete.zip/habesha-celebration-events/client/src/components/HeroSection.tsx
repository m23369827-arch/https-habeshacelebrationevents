/* ============================================================
   HERO SECTION — Ethiopian Royal Court Maximalism
   Full-bleed hero with overlay, animated text, gold CTA
   ============================================================ */
import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/hero-ethiopian-couple-celebration-gp4MMf7A2rqmaPqk7u5kRU.webp";

export default function HeroSection() {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 200);
    return () => clearTimeout(timer);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${HERO_IMAGE})` }}
      />
      {/* Layered overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-midnight/80 via-midnight/60 to-midnight/90" />
      <div className="absolute inset-0 bg-gradient-to-r from-midnight/70 via-transparent to-midnight/70" />

      {/* Tibeb stripe at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-1 tibeb-border" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        {/* Section label */}
        <div
          className={`transition-all duration-1000 delay-100 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          <p className="section-label mb-4">
            <span className="eth-cross">✦</span>
            {t("hero.headline")}
            <span className="eth-cross">✦</span>
          </p>
        </div>

        {/* Logo Image */}
        <div
          className={`transition-all duration-1000 delay-200 mb-6 flex justify-center ${visible ? "opacity-100 scale-100" : "opacity-0 scale-90"}`}
        >
          <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663416578238/DKWchE49iri6vKpCF4PuCd/upscalemedia-transformed_81a4220c.jpeg" alt="Habesha Logo" className="h-32 w-32 object-contain" />
        </div>

        {/* Main heading */}
        <div
          className={`transition-all duration-1000 delay-300 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <h1
            style={{ fontFamily: "'Cinzel Decorative', serif" }}
            className="text-ivory text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-2"
          >
            Habesha
          </h1>
          <h1
            style={{ fontFamily: "'Cinzel Decorative', serif" }}
            className="text-gold-gradient text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
          >
            Celebration Events
          </h1>
        </div>

        {/* Divider */}
        <div
          className={`transition-all duration-1000 delay-500 ${visible ? "opacity-100" : "opacity-0"}`}
        >
          <div className="gold-divider" />
        </div>

        {/* Tagline */}
        <div
          className={`transition-all duration-1000 delay-600 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          <p
            style={{ fontFamily: "'Crimson Text', serif" }}
            className="text-ivory/90 text-xl sm:text-2xl md:text-3xl italic font-light mb-3 leading-relaxed"
          >
            "{t("hero.subheadline")}"
          </p>
        </div>

        {/* CTA Buttons */}
        <div
          className={`flex flex-col sm:flex-row gap-4 justify-center items-center transition-all duration-1000 delay-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          <button
            onClick={() => scrollToSection("#contact")}
            className="btn-gold"
          >
            {t("hero.cta")}
          </button>
          <button
            onClick={() => scrollToSection("#services")}
            className="btn-gold-outline"
          >
            {t("nav.services")}
          </button>
        </div>

        {/* Stats */}
        <div
          className={`mt-16 grid grid-cols-3 gap-8 max-w-lg mx-auto transition-all duration-1000 delay-900 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
        >
          {[
            { number: "500+", label: "Events Planned" },
            { number: "10+", label: "Years Experience" },
            { number: "100%", label: "Client Satisfaction" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div
                style={{ fontFamily: "'Cinzel', serif" }}
                className="text-gold text-2xl sm:text-3xl font-bold"
              >
                {stat.number}
              </div>
              <div
                style={{ fontFamily: "'Lato', sans-serif" }}
                className="text-ivory/50 text-xs tracking-widest uppercase mt-1"
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={() => scrollToSection("#about")}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-gold/60 hover:text-gold transition-colors animate-bounce"
        aria-label="Scroll down"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
}
